TOOLS

scd:
	This batch tool is used to navigate through short path names. Nice to use with the WDK for
    building in directories with spaces. Currently being used by the build scripts.
